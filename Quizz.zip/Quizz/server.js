const express = require('express');
const http = require('http');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// Serve static files from the 'public' directory
app.use(express.static('public'));

io.on('connection', (socket) => {
    console.log('A user connected');

    // Handle quiz submission
    socket.on('submitQuiz', (answers) => {
        // Implement your server-side logic to validate and score the quiz
        const score = calculateScore(answers);

        // Broadcast the result to all connected clients
        io.emit('quizResult', { score });
    });

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});

function calculateScore(answers) {
    // Implement your scoring logic based on correct answers
    const correctAnswers = {
        q1: 'paris',
        q2: 'jupiter',
        q3: 'tokyo',
        q4: '1945',
        q5: 'shakespeare',
        q6: 'pacific',
        q7: 'fitzgerald',
        q8: 'sahara',
        q9: 'fleming',
        q10: 'aud',
        q11: 'da_vinci',
        q12: 'mars',
        q13: 'blue_whale',
        q14: 'vangogh',
        q15: 'brl'
    };

    let score = 0;

    // Compare user answers with correct answers and calculate the score
    Object.keys(answers).forEach((question) => {
        const userAnswer = answers[question];
        const correctAnswer = correctAnswers[question];

        if (userAnswer === correctAnswer) {
            score++;
        }
    });

    return score;
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
